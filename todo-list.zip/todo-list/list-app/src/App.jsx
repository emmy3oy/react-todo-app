import { useState } from 'react';
import './App.css';




function App() {
const [ todo, setTodo] = useState("");
const [todoList, setTodoList] = useState([]);
//Handle Form Component
const handleForm = (e) => {
  e.preventDefault();
  setTodoList([...todoList, {todoName: todo }]);
  setTodo("");
};

//Function to Delete Todo List
const deleteTodo = (deleteValue) => {
  const restTodoList = [...todoList.filter((val) => {
    return val.todoName !== deleteValue;
  }),
];
setTodoList(restTodoList);

};

return (
    <div className='main-head'>
      <div className='head'>
        <h1 className='header'>TO-DO LIST</h1>
  
        <form onSubmit={handleForm}>
          <input 
          type="text" 
          placeholder='Add List'
          value={todo}
          onChange={(e) => setTodo(e.target.value)}/>
          <button className='todo-btn' type='submit'>Add Todo</button>
        </form>
        <div className='todo-list'>
          <ul>
             {todoList.map((singleTodo, index) => {
              
              return(
                 <li key={index}> 
                  {singleTodo.todoName}{" "} 
                  <span onClick={() => deleteTodo(singleTodo.todoName)} className='delete-btn'>delete</span>
                </li>
               );
              })}
          </ul>
        </div>
      </div>
    </div>
);
}


export default App;